import Car from 'images/car.jpg';
import s from './style.scss';

function App() {
  return (
    <div className={s.block}>
      <div className={s.element}>
        <img src={Car} alt='Картинка' />
      </div>
      <h1 className={s.h1}>Заголовок</h1>
    </div>
  );
}

export default App;
