module.exports = {
  plugins: [
    [
      'postcss-import',
      {
        path: ['src/styles'],
        plugins: [require('stylelint')],
      },
    ],
    'cssnano',
    'postcss-advanced-variables',
    'postcss-preset-env',
    'postcss-nested',
  ],
};
